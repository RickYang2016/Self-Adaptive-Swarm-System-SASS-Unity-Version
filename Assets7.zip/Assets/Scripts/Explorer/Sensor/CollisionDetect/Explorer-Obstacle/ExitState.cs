﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ExitState : MonoBehaviour
{
    public string ID;
    public Vector3 Pos;

    // Start is called before the first frame update
    void Start()
    {
        ID = gameObject.name;
        Pos = gameObject.transform.position;
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
