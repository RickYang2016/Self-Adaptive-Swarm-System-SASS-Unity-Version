﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ExplorerAttackingEnergyCost : MonoBehaviour
{
    public float attackingEnergyCost = 0;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    private void OnTriggerStay(Collider agent)
    {
        if(agent.tag == "MonsterBody")
        {
            attackingEnergyCost = gameObject.GetComponentInParent<AgentState>().unitAttackingEnergyCost;
        }
    }

    private void OnTriggerExit(Collider agent)
    {
        if(agent.tag == "MonsterBody")
        {
            attackingEnergyCost = 0;
        }
    }
}
