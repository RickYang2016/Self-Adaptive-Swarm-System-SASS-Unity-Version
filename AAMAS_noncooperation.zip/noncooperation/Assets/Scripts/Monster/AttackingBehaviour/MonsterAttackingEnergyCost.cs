﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MonsterAttackingEnergyCost : MonoBehaviour
{
    public float attackingEnergyCost = 0;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    private void OnTriggerStay(Collider agent)
    {
        if(agent.tag == "ExplorerBody")
        {
            attackingEnergyCost = gameObject.GetComponentInParent<MonsterState>().unitAttackingEnergyCost;
        }
    }

    private void OnTriggerExit(Collider agent)
    {
        if(agent.tag == "ExplorerBody")
        {
            attackingEnergyCost = 0;
        }
    }
}
