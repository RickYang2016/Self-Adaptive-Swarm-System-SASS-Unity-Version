﻿using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using UnityEngine;
using System;
using System.Linq;
using System.Text;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Json;

[System.Serializable]
public class MonsterDecision
{
    public MonsterLevel1Decision level_1_decision;
    public MonsterLevel2Decision level_2_decision;
    public MonsterLevel3Decision level_3_decision;
    public MonsterLevel1MonsterDecision level_1_decision_m;
    public MonsterLevel2MonsterDecision level_2_decision_m;
    public MonsterLevel3MonsterDecision level_3_decision_m;
}

[System.Serializable]
public class MonsterLevel1Decision
{
    public string attack;
    public string patrol;
    public string defend;
}

[System.Serializable]
public class MonsterLevel2Decision
{
    public string nearest;
    public string lowest_attacking_ability;
    public string highest_attacking_ability;
}

[System.Serializable]
public class MonsterLevel3Decision
{
    public string Independent;
    public string Dependent;
}

[System.Serializable]
public class MonsterLevel1MonsterDecision
{
    public string attack;
    public string patrol;
    public string defend;
}

[System.Serializable]
public class MonsterLevel2MonsterDecision
{
    public string nearest;
    public string lowest_attacking_ability;
    public string highest_attacking_ability;
}

[System.Serializable]
public class MonsterLevel3MonsterDecision
{
    public string Independent;
    public string Dependent;
}

public class ImportMonDecLevel : MonoBehaviour
{
    public string monsterLevel1Decision;
    public string monsterLevel2Decision;
    public string monsterLevel3Decision;
    public int decisionTimes = 0;
    private MonsterDecision loadedData;
    private int newNumExplorers;
    private int oldNumExplorers;
    private int newChangeNumExplorers;
    private int oldChangeNumExplorers;
    private List<List<float>> explorersInfo;
    private List<List<float>> monstersInfo;
    // private string explorersListPath = "/home/herobot/Documents/research/data/exploer_game/monsterDecExplorersList.txt";
    // private string monstersDecisionListPath = "/home/herobot/Documents/research/data/exploer_game/monsterDecMonstersList.txt";
    // private string monsterDecisionPath = "/home/herobot/Documents/research/code/MonstersDecision.json";

    // socket communication parameters
    // private string message;
    private Socket client;
    private string host = "127.0.0.1";
    private int port = 21567;
    private byte[] messTmp;
    private Thread connectThread;
    private byte[] input;
    private MonsterDecision decision;
    private string tmpf;

    // Start is called before the first frame update
    void Start()
    {
        messTmp = new byte[1024];
    }

    // Update is called once per frame
    void Update()
    {
        newNumExplorers = gameObject.GetComponent<MonsterCom>().perceptionList.Count;
        newChangeNumExplorers = newNumExplorers - oldNumExplorers;

        if(gameObject.GetComponent<MonsterCom>().perceptionList.Count != 0)
        {
            explorersInfo = GetDataFromExplorers(gameObject.GetComponent<MonsterCom>().perceptionList);

            // condition 1: only consider current monster
            List<MonsterState> tmpMonsterList = new List<MonsterState>();
            tmpMonsterList.Add(gameObject.GetComponent<MonsterState>());
            monstersInfo = GetDataFromMonsters(tmpMonsterList);

            // condition 2: consider percepted agents
            // monstersInfo = GetDataFromMonsters(gameObject.GetComponent<MonsterCom>().CommunicationList);

            List<string> tmpe = new List<string>();
            List<string> tmpm = new List<string>();

            // if(explorersInfo != null)
            {
                foreach(var item in explorersInfo)
                {
                    string tmp = string.Join(",", item);
                    tmpe.Add(tmp);
                }

                foreach(var item in monstersInfo)
                {
                    string tmp = string.Join(",", item);
                    tmpm.Add(tmp);
                }

                tmpe.AddRange(tmpm);
                tmpe.Insert(0, "monster");

                tmpf = GetJsonStringByObject(tmpe);
            }
        }

        // if MonstersList has changed and changing times are not equal, recalculate the decision
        if(newChangeNumExplorers != 0 && newChangeNumExplorers != oldChangeNumExplorers)
        {
            // update agent's energy state
            gameObject.GetComponent<MonsterState>().agentEnergy = gameObject.GetComponent<MonsterRouting>().currentAgentEnergy;

            decisionTimes++;

            // send the state infoamtion to decision level for calculating and receive the computing results
            if(gameObject.GetComponent<MonsterState>().agentHP > 10f)
            {
                SendMessage();
                GetMessage();
            }

            // update decision results
            LoadDecisionResult();          
        }
        else if(newNumExplorers == 0)
        {
            monsterLevel1Decision = "Patroling";
            monsterLevel2Decision = "Nearest";
            monsterLevel3Decision = "Independent";           
        }

        oldChangeNumExplorers = newChangeNumExplorers;
        oldNumExplorers = newNumExplorers;        
    }

    // get two opponent groups average distance
    private float GetAverageDis()
    {
        float averageDis = 0;
        List<float> disMatrix  = new List<float>();;

        if(gameObject.GetComponent<MonsterCom>().perceptionList != null)
        {
            foreach(var item in gameObject.GetComponent<MonsterCom>().perceptionList)
            {
                disMatrix.Add(Vector3.Distance(gameObject.GetComponent<MonsterState>().agentPos, item.agentPos));
            }
        }

        averageDis = disMatrix.Sum() / gameObject.GetComponent<MonsterCom>().perceptionList.Count;

        return averageDis;
    }

    // get all the perceptionList data to list
    private List<List<float>> GetDataFromExplorers(List<perceptiveExplorerState> perceptionList)
    {
        List<List<float>> agentsInfo = new List<List<float>>();

        foreach(var item in perceptionList)
        {
            List<float> agentInfo = new List<float>();

            agentInfo.Add(item.unitAttackingEnergyCost);
            agentInfo.Add(item.agentEnergy);
            agentInfo.Add(item.agentHP);
            agentInfo.Add(Convert.ToSingle(Math.Pow(item.agentRadius, 2.0) * Math.PI));
            agentInfo.Add(item.agentSpeed);
            agentInfo.Add(GetAverageDis());

            agentsInfo.Add(agentInfo);
        }

        return agentsInfo;
    }

    // get Monster's data to list
    // private List<List<float>> GetDataFromMonsters(MonsterState Monster)
    // {
    //     List<List<float>> agentsInfo = new List<List<float>>();
    //     List<float> agentInfo = new List<float>();

    //     agentInfo.Add(Monster.unitAttackingEnergyCost);
    //     agentInfo.Add(Monster.agentEnergy);
    //     agentInfo.Add(Monster.agentHP);
    //     agentInfo.Add(Convert.ToSingle(Math.Pow(Monster.agentRadius, 2.0) * Math.PI));
    //     agentInfo.Add(Monster.agentSpeed);
    //     agentInfo.Add(GetAverageDis());

    //     agentsInfo.Add(agentInfo);
        
    //     return agentsInfo;
    // }

    private List<List<float>> GetDataFromMonsters(List<MonsterState> MonsterList)
    {
        List<List<float>> agentsInfo = new List<List<float>>();

        foreach(var item in MonsterList)
        {
            List<float> agentInfo = new List<float>();

            agentInfo.Add(item.unitAttackingEnergyCost);
            agentInfo.Add(item.agentEnergy);
            agentInfo.Add(item.agentHP);
            agentInfo.Add(Convert.ToSingle(Math.Pow(item.agentRadius, 2.0) * Math.PI));
            agentInfo.Add(item.agentSpeed);
            agentInfo.Add(GetAverageDis());

            agentsInfo.Add(agentInfo);
        }
                
        return agentsInfo;
    }

    // update the decision results from decision level
    private void LoadDecisionResult()
    {
        if(decision != null)
        {
            loadedData = decision;

            // if(File.Exists(monsterDecisionPath))
            // {
            //     string dataJson = File.ReadAllText(monsterDecisionPath);

            //     loadedData = JsonUtility.FromJson<MonsterDecision>(dataJson);
            // }

            // get level 1 decision
            try
            {
                if(Convert.ToSingle(loadedData.level_1_decision_m.patrol) != 0)
                {
                    monsterLevel1Decision = "Patroling";
                }
                else if(Convert.ToSingle(loadedData.level_1_decision_m.attack) != 0)
                {
                    monsterLevel1Decision = "Attacking";
                }
                else if(Convert.ToSingle(loadedData.level_1_decision_m.defend) != 0)
                {
                    monsterLevel1Decision = "Defending";
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                return;
            }

            // get level 2 decision
            try
            {
                if(Convert.ToSingle(loadedData.level_2_decision_m.nearest) != 0)
                {
                    monsterLevel2Decision = "Nearest";
                }
                else if(Convert.ToSingle(loadedData.level_2_decision_m.lowest_attacking_ability) != 0)
                {
                    monsterLevel2Decision = "Lowest Attacking Ability";
                }
                else if(Convert.ToSingle(loadedData.level_2_decision_m.highest_attacking_ability) != 0)
                {
                    monsterLevel2Decision = "Highest Attacking Ability";
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                return;
            }

            // get level 3 decision
            try
            {
                if(Convert.ToSingle(loadedData.level_3_decision_m.Independent) != 0)
                {
                    monsterLevel3Decision = "Independent";
                }
                else if(Convert.ToSingle(loadedData.level_3_decision_m.Dependent) != 0)
                {
                    monsterLevel3Decision = "Dependent";
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                return;
            }
        }

        print("The monsters' decision are: " + "{Level1: " + monsterLevel1Decision + "; Level2: " + monsterLevel2Decision + "; Level3: " + monsterLevel3Decision + "}");
    }

    private void GetMessage()
    {
        var count = client.Receive(messTmp);

        if (count != 0)
        {
            string dataJson = Encoding.UTF8.GetString(messTmp, 1, count - 2);

            // print("The monsters' decision are " + dataJson);

            // print("The " + gameObject.GetComponent<MonsterState>().ID + "'s decision are: " + dataJson);

            // print("The " + decisionTimes + " time of " + gameObject.GetComponent<MonsterState>().ID + "'s decision are: " + dataJson);

            decision = JsonUtility.FromJson<MonsterDecision>(dataJson);

            Array.Clear(messTmp, 0, count);
        }

        client.Close();
    }

    // serialize
    private string GetJsonStringByObject(object obj)
    {
        DataContractJsonSerializer serialier = new DataContractJsonSerializer(obj.GetType());

        MemoryStream stream = new MemoryStream();

        serialier.WriteObject(stream, obj);

        byte[] dataBytes = new byte[stream.Length];

        stream.Position = 0;

        stream.Read(dataBytes, 0, (int)stream.Length);

        string msg = Encoding.UTF8.GetString(dataBytes.ToArray());

        return msg;
    }

    private void SendMessage()
    {
        // initiate a new socket
        client = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);

        try
        {
            client.Connect(new IPEndPoint(IPAddress.Parse(host), port));
        }
        catch (Exception e)
        {
            Console.WriteLine(e.Message);
            return;
        }

        // send the current state information 
        input = new byte[1024];

        string jsonString = tmpf;

        input = Encoding.UTF8.GetBytes(jsonString);

        try
        {
            client.Send(input);                
        }
        catch(Exception e)
        {
            Console.WriteLine(e.Message);
            return;
        }
    }

    // get the decision results depending on different scenarios
    private void GetDecisionResult()
    {

    }

    // // store the explorers' data in file
    // private void saveEStore(List<List<float>> agentsInfo)
    // {
    //     StreamWriter inputPyExplorersData;

    //     inputPyExplorersData = new StreamWriter(explorersListPath, false);
            
    //     for(int i = 0; i < agentsInfo.Count; i++)
    //     {
    //         string data = " ";

    //         for(int j = 0; j < agentsInfo[i].Count; j++)
    //         {
    //             data += agentsInfo[i][j];

    //             if(j != agentsInfo[i].Count - 1)
    //             {
    //                 data += ",";
    //             }
    //         }

    //         inputPyExplorersData.WriteLine(data);            
    //     }

    //     inputPyExplorersData.Close();
    //     agentsInfo.Clear();
    // }

    // // store the monsters' data in file
    // private void saveMStore(List<List<float>> agentsInfo)
    // {
    //     StreamWriter inputPyMonstersData;

    //     inputPyMonstersData = new StreamWriter(monstersListPath, false);

    //     for(int i = 0; i < agentsInfo.Count; i++)
    //     {
    //         string data = " ";

    //         for(int j = 0; j < agentsInfo[i].Count; j++)
    //         {
    //             data += agentsInfo[i][j];

    //             if(j != agentsInfo[i].Count - 1)
    //             {
    //                 data += ",";
    //             }
    //         }

    //         inputPyMonstersData.WriteLine(data);            
    //     }

    //     inputPyMonstersData.Close();
    //     agentsInfo.Clear();
    // }
}
