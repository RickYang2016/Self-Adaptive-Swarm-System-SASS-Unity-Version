﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine;

public class TreasureInfo : MonoBehaviour
{
    public Text Info = null;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        // show the treasure information
        Info.transform.position = transform.position + new Vector3(0, 6, 0);
        Info.fontSize = 1;
        Info.text = "Treasure"; 
    }
}
