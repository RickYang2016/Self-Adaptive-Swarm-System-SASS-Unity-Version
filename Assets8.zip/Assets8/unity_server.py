import socket
import threading
import json
import SGDT_version_2_update

# sendData = { 
#  	"infolist":
#  	[
#  		{
#  			"name": "fefa",
#  			"age": "34"
#  		},
#  		{
#  			"name": "hrg",
#  			"age": "21"
#  		}
#  	]
# }



def on_new_connection(client_executor, addr):
	print('Accept new connection from %s:%s...' % addr)

	# recy_thread = threading.Thread(target=message_receiver, args=(client_executor,addr))
	# recy_thread.start()

	i = 0
	# while True:
	client_executor.send(bytes(repr(json.dumps(sendData)).encode('utf-8')))
	i = i + 1
	print('i is ' + str(i))
	# client_executor.send(bytes(json.dumps(sendData).encode('utf-8')))

	client_executor.close()
	print('Connection from %s:%s closed.' % addr)

def message_receiver(client_executor, addr):

	j = 0
	msg = client_executor.recv(1024).decode('utf-8')
	# print(json.loads(msg))

    # while True:
    #     with open('server.txt','a+') as f:
    #         msg = client_executor.recv(1024).decode('utf-8')
    #         f.writelines('%s:%s: %s \r\n' % (addr[0], addr[1], msg))
    
    # j = 0
    # while True:

	# msg = client_executor.recv(1024).decode('utf-8')

	print('%s:%s: %s' % (addr[0], addr[1], json.loads(msg)))
	j = j + 1
	print('j is ' + str(j))

	sendData = SGDT_version_2_update.getResult(msg)
	print(sendData)

	i = 0
	# while True:
	client_executor.send(bytes(repr(json.dumps(sendData)).encode('utf-8')))
	i = i + 1
	print('i is ' + str(i))


# sendData = SGDT_version_2_update.getResult()
# print(sendData)
listener = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
listener.bind(('172.23.89.174', 21567))
listener.listen(5)
print('Waiting for connect...')

while True:
	client_executor, addr = listener.accept()
	t = threading.Thread(target=message_receiver, args=(client_executor, addr))
	print("I am accepting!")

	# t = threading.Thread(target=on_new_connection, args=(client_executor, addr))
	t.start()