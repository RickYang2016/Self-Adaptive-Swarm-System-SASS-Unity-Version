import socket
import threading
import json
import SGDT_version_2_update
import SGDT_version_2_monster_update

def message_receiver(client_executor, addr):

	j = 0
	msg = client_executor.recv(2048).decode('utf-8')
	agentsInfo = json.loads(msg)

	# if message come from explorer, use "SGDT_version_2_update.py" to calculate.
	if agentsInfo[0] == "explorer":
		agentsInfo.pop(0)
		print('%s:%s: %s' % (addr[0], addr[1], agentsInfo))
		j = j + 1
		print('j is ' + str(j))

		sendData = SGDT_version_2_update.getResult(agentsInfo)
	# if message come from monster, use "SGDT_version_2_monster_update.py" to calculate.
	elif agentsInfo[0] == "monster":
		agentsInfo.pop(0)
		print('%s:%s: %s' % (addr[0], addr[1], agentsInfo))
		j = j + 1
		print('j is ' + str(j))

		sendData = SGDT_version_2_monster_update.getResult(agentsInfo)
	else:
		print("Have some problems in message classifing!")

	print(sendData)

	i = 0
	client_executor.send(bytes(repr(json.dumps(sendData)).encode('utf-8')))
	i = i + 1
	print('i is ' + str(i))

if __name__ == '__main__':

	listener = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
	listener.bind(('127.0.0.1', 21567))
	listener.listen(5)
	print('Waiting for connect...')

	while True:
		client_executor, addr = listener.accept()
		t = threading.Thread(target=message_receiver, args=(client_executor, addr))
		print("I am accepting!")
		t.start()