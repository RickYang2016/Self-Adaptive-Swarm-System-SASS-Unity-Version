# -*- coding: utf-8 -*

import numpy as np
import scipy.stats
import matplotlib.pyplot as plt
import seaborn as sns
import pandas
from scipy import stats, integrate

# def demo2():
#     mu, sigma , num_bins = 0, 1, 50
#     x = mu + sigma * np.random.randn(1000000)
#     # 正态分布的数据
#     n, bins, patches = plt.hist(x, num_bins, normed=True, facecolor = 'blue', alpha = 0.5)
#     # 拟合曲线
#     y = mlab.normpdf(bins, mu, sigma)
#     plt.plot(bins, y, 'r--')
#     plt.xlabel('Expectation')
#     plt.ylabel('Probability')
#     plt.title('histogram of normal distribution: $\mu = 0$, $\sigma=1$')

#     plt.subplots_adjust(left = 0.15)
#     plt.show()

# demo2()

width = 0.3
source = [221, 72, 966, 42]

names = ['1010001', '1001001','0101001', '0110001']
mu = np.mean(source)
sigma = np.std(source)
# bins = len(source)
# n, bins, patches = plt.hist(source, 4, normed=1, facecolor='green', alpha=0.75)
y = scipy.stats.norm.pdf(4, mu, sigma)
plt.plot(4, y, 'r--')

print(mu, sigma)

# tactics_dic = dict(zip(names, source))
tactics_dic = {'2': 72, '1': 221, '3': 966, '4': 42}
# plt.xlabel(names)
plt.bar(tactics_dic.keys(), tactics_dic.values(), width, color='g')
plt.xlabel('Tactics')
plt.ylabel('Times')
# sns.distplot(source)
# sns.distplot(np.random.normal(size=100),kde=True)
# x = np.random.gamma(6, size=200)
# sns.distplot(x, kde=False, fit=stats.gamma)
plt.show()