import matplotlib.pyplot as plt
from dateutil.parser import parse
import time
import math
import numpy as np
import os
import itertools as it
from datetime import datetime

complete_info = "/home/herobot/Documents/research/data/explorer_game/obstacle_bar/com"
incomplete_info_linear = "/home/herobot/Documents/research/data/explorer_game/obstacle_bar/incom_linear"
incomplete_info_nonlinear = "/home/herobot/Documents/research/data/explorer_game/incom_nonlinear"
noncooperation_info = "/home/herobot/Documents/research/data/explorer_game/obstacle_bar/noncooperate"

files1 = os.listdir(complete_info)
files2 = os.listdir(incomplete_info_linear)
files3 = os.listdir(incomplete_info_nonlinear)
files4 = os.listdir(noncooperation_info)

explorer_strategy = ['a_n_3', 'd_n_3']
monster_strategy = ['a_n_i', 'a_l_i', 'd_n_i', 'd_l_i']

# complete info 
for file1 in files1:
	if not os.path.isdir(file1):
		ratio1, attacking_nearest_three_groups, defending_nearest_three_groups, attacking_nearest_independent, attacking_lowest_independent, defending_nearest_independent, defending_lowest_independent = [],[],[],[],[],[],[]
		f1 = open(complete_info + "/" + file1, "r");

		for line in f1:
			value1 = [str(s) for s in line.split()]
			ratio1.append(value1[0])
			attacking_nearest_three_groups.append(float(value1[1]))
			defending_nearest_three_groups.append(float(value1[2]))
			attacking_nearest_independent.append(float(value1[3]))
			attacking_lowest_independent.append(float(value1[4]))
			defending_nearest_independent.append(float(value1[5]))
			defending_lowest_independent.append(float(value1[6]))

			print(value1)

plt.figure()
plt.title('25 Explorers Fixed', fontsize = 15)
# plt.bar(ratio1, attacking_nearest_three_groups)
# plt.bar(ratio1, defending_nearest_three_groups)
plt.bar(monster_strategy, attacking_nearest_independent)
plt.bar(monster_strategy, attacking_lowest_independent)
plt.bar(monster_strategy, defending_nearest_independent)
plt.bar(monster_strategy, defending_lowest_independent)


# plt.scatter(ratio11[4:], kill_per_monster_HP_cost11[4:], color = '', marker = 'o', edgecolors = 'indigo', s = 150)
# plt.scatter(ratio21[4:], kill_per_monster_HP_cost21[4:], color = '', marker = 'o', edgecolors = 'indigo', s = 150)
# plt.scatter(ratio31[4:], kill_per_monster_HP_cost31[4:], color = '', marker = 'o', edgecolors = 'indigo', s = 150)
# plt.scatter(ratio41, kill_per_monster_HP_cost41, color = '', marker = 'o', edgecolors = 'indigo', s = 150)

plt.xlabel('lg(Ratio(Monsters vs Explorers))', fontsize = 15)
plt.ylabel('Kill Per Monster Explorer HP Cost', fontsize = 15)
# plt.legend(['Complete Info','Incomplete Info Linear', 'Incomplete Info Nonlinear', 'Noncooperation Info', 'Incomplete Task Label'], loc='lower right', bbox_to_anchor=(1, 0.15))
plt.show()