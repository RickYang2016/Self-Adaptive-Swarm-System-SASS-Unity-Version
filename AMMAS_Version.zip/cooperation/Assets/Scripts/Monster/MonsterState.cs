﻿using System.Collections;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using UnityEngine;
using System;

public class MonsterState : MonoBehaviour
{
    public string ID;
    public float agentEnergy;
    public float agentHP;
    public float agentRadius;
    public float agentSpeed;
    public float unitHPCost;
    public float unitAttackingEnergyCost;
    public float estimationExplorerEnergyLevel;
    public float estimationExplorerHPLevel;
    public float estimateUnitExplorerAttackingEnergyCost;
    public Vector3 agentPos;
    public Vector3 safetyPos;
    public string level1Decision;
    public string level2Decision;
    public string level3Decision;

    // Start is called before the first frame update
    private void Start()
    {
        ID = gameObject.name;
        agentRadius = 5f;
        safetyPos = GetSafetyPos(ID);
        agentSpeed = 5.0f;
        unitAttackingEnergyCost = 0.03f;
        unitHPCost = gameObject.GetComponentInChildren<MonsterAttackingState>().unitHPCost;
        // level2Decision = "Nearest";
    }

    // Update is called once per frame
    void Update()
    {
        agentEnergy = gameObject.GetComponent<MonsterRouting>().currentAgentEnergy - gameObject.GetComponentInChildren<MonsterAttackingEnergyCost>().attackingEnergyCost;
        agentHP = gameObject.GetComponentInChildren<MonsterAttackingState>().currentHP;

        level1Decision = gameObject.GetComponent<ImportMonDecLevel>().monsterLevel1Decision;

        if(level1Decision == "")
        {
            level2Decision = "Nearest";
        }
        else
        {
            level2Decision = gameObject.GetComponent<ImportMonDecLevel>().monsterLevel2Decision;
        }

        level3Decision = gameObject.GetComponent<ImportMonDecLevel>().monsterLevel3Decision;
    }

    private Vector3 GetSafetyPos(string ID)
    {
        float tmp = 0;
        Vector3 safetyPos = new Vector3();

        string tmps = Regex.Replace(ID, "[a-z]", "", RegexOptions.IgnoreCase);
        float.TryParse(tmps, out tmp);

        // safetyPos = new Vector3(tmp * -100f, 0.25f, tmp * -100);
        safetyPos = new Vector3(tmp * -15, 10f, 600);

        return safetyPos;
    }

    public float GetEstimatedUnitExplorerAttackingEnergyCost(string id)
    {
        float tmp = 0;

        string tmps = Regex.Replace(id, "[a-z]", "", RegexOptions.IgnoreCase);
        float.TryParse(tmps, out tmp);

        // estimate the adversary's unit attacking energy cost from agents' per attack HP cost from the adversary
        // linear prediction model: y = a * x + b
        // estimateUnitExplorerAttackingEnergyCost = 0.08f * unitHPCost + 0.001f * Convert.ToSingle(tmp);

        // nonlinear prediction model: y = a * ln(bx) + c
        estimateUnitExplorerAttackingEnergyCost = -Convert.ToSingle(Math.Log(unitHPCost * Convert.ToSingle(tmp) * 0.1f)) * 0.005f;

        return estimateUnitExplorerAttackingEnergyCost;
    }

    public float GetEstimatedExplorerEnergyLevel(string id)
    {
        float tmp = 0;

        string tmps = Regex.Replace(id, "[a-z]", "", RegexOptions.IgnoreCase);
        float.TryParse(tmps, out tmp);

        // estimate the adversary's energy level from agents' HP cost from the adversary
        // linear prediction model: y = a * x + b
        // estimationExplorerEnergyLevel = 100 - (100 - agentHP) * Convert.ToSingle(Math.Pow(Convert.ToSingle(tmp), 1/4)) / gameObject.GetComponent<MonsterCom>().perceptionList.Count;

        // nonlinear prediction model: y = a * ln(bx) + c
        if(agentHP == 100)
        {
            estimationExplorerEnergyLevel = 100;
        }
        else
        {
            estimationExplorerEnergyLevel = 100 - Convert.ToSingle(Math.Log(agentHP * Convert.ToSingle(tmp))) * 0.1f;            
        }

        return estimationExplorerEnergyLevel;
    }

    public float GetEstimationExplorerHPLevel(string id)
    {
        float tmp = 0;

        string tmps = Regex.Replace(id, "[a-z]", "", RegexOptions.IgnoreCase);
        float.TryParse(tmps, out tmp);

        // estimate the adversary's energy level from agent's current attacking energy cost
        // linear prediction model: y = a * x + b
        estimationExplorerHPLevel = 100 - 10 * gameObject.GetComponentInChildren<MonsterAttackingEnergyCost>().attackingEnergyCost * Convert.ToSingle(tmp);


        // nonlinear prediction model: y = a * ln(bx) + c


        return estimationExplorerHPLevel;

    }
}
